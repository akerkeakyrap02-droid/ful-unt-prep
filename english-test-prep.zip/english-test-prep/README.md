# English Test Prep

Grammar and vocabulary practice for the Kazakhstan UNT (ENT). Students practise topic by topic; the teacher adds tests a few at a time.

The site is plain HTML, CSS and JavaScript. There is no build step, so GitHub Pages can host it directly. Supabase (Postgres + auth) stores everything.

**Build progress:** Step 1 of 6 (database + auth) is done. Next: topic cards, teacher test creation, student test flow, results, dashboard.

## 1. Create the database (Supabase, free tier)

1. Create a project at supabase.com.
2. **Authentication -> Providers -> Email:** turn **off** "Confirm email". Students who sign up with only a username have no real inbox.
3. **SQL Editor:** run `supabase/schema.sql`, then `supabase/seed.sql`.
4. **Project Settings -> API:** copy the Project URL and the `anon` public key into `js/config.js`.

Never put the `service_role` key anywhere in this repository.

Demo logins from the seed file (change or delete before real use):

| Role | Login | Password |
|---|---|---|
| Teacher | teacher@example.com | Teacher123! |
| Student | student@example.com (or username `student`) | Student123! |

To make a real account a teacher, run in the SQL Editor:

```sql
update public.profiles set role = 'teacher' where email = 'your-email@example.com';
```

## 2. Publish on GitHub Pages

1. Create a new GitHub repository and upload everything in this folder (keep the `.nojekyll` file).
2. **Settings -> Pages -> Build and deployment:** Source = "Deploy from a branch", Branch = `main`, folder = `/ (root)`.
3. After a minute the site is live at `https://<your-username>.github.io/<repo-name>/`.
4. In Supabase, **Authentication -> URL Configuration**, set the Site URL to that address.

## How security works

- Row-level security is on for every table. Students can read only published tests and only their own attempts and answers.
- Correct answers live in a separate table, `question_keys`, that students cannot read. Grading runs in the database function `submit_attempt()`, and the answer sheet comes from `get_attempt_review()`, which only returns answers after submission.
- A student cannot change their own role, group or grading fields (database triggers enforce this).
- Sign-up always creates a `student`. Teachers are promoted by SQL only.

## Differences from the original spec

- `users` is called `profiles` (Supabase keeps its own `auth.users`).
- `correct_answer` and `explanation` moved from `questions` to `question_keys` so they can never reach a student's browser.
- Added: `groups.name`, `tests.published_at` (drives the 7-day "New" badge), `tests.shuffle_*`, `assignments`, and two views (`topic_cards`, `live_tests`).
- Teacher password resets need a Supabase Edge Function (the browser cannot hold the service key). That comes with step 7 of the teacher tools.
